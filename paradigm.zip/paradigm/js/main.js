/* Paradigm: main panels and boot */
'use strict';

const VERSION = '1.0.0';
let panel = 'stack';
let backSel = [];

function goPanel(name) {
  panel = name;
  const x = { backlog: 0, stack: -33.3333, settings: -66.6667 }[name];
  $('#track').style.transform = `translateX(${x}%)`;
  hideSuggest();
  if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
}

/* ---------- blocks ---------- */
function blockEl(bid) {
  const b = state.blocks[bid], it = state.items[b.itemId], l = blockLabel(bid);
  const el = document.createElement('div');
  el.className = 'block';
  el.dataset.key = bid;
  let meta = '';
  if (it.type === 'list' && !b.subId && it.subtasks.length) meta += `<span class="meta">${it.subtasks.filter(s => s.done).length}/${it.subtasks.length}</span>`;
  if (b.elapsed) meta += `<span class="meta">${fmtShort(b.elapsed)}</span>`;
  if (it.recurring && !b.subId) meta += '<span class="mark" aria-label="Recurring">↻</span>';
  el.innerHTML = `<span class="name">${l.proj ? `<span class="proj">${esc(l.proj)} ›</span> ` : ''}${esc(l.name)}</span>${meta}`;
  return el;
}

function renderAll() {
  if (!state) return;
  renderStack(); renderBacklog(); renderSettings(); renderRunbar();
}

/* ---------- STACK ---------- */
function renderStack() {
  renderPlace();
  const list = $('#stack-list');
  list.innerHTML = '';
  state.stack.forEach(bid => list.appendChild(blockEl(bid)));
  wireList(list, {
    reverse: true,
    onReorder: keys => { state.stack = keys; save(); },
    swipeRight: bid => openStartPicker(bid),
    swipeLeft: bid => withUndo('Sent to BACKLOG', () => { detach(bid); state.backlog.unshift(bid); })
  });
  $('#stack-empty').classList.toggle('hidden', !!(state.stack.length || state.placing.length));
}

function renderPlace() {
  const z = $('#place-zone');
  z.innerHTML = '';
  if (!state.placing.length) return;
  const bid = state.placing[0];
  const blk = blockEl(bid);
  z.appendChild(blk);
  const hint = document.createElement('p');
  hint.className = 'hint';
  hint.textContent = (state.stack.length ? 'Hold and drag into place.' : 'Tap or drag to place.') + ' Swipe right to start, left for BACKLOG.';
  z.appendChild(hint);
  let drag = null;
  gesture(blk, {
    onSwipeRight: () => openStartPicker(bid),
    onSwipeLeft: () => { detach(bid); state.backlog.push(bid); save(); renderAll(); toast('Sent to BACKLOG'); },
    onTap: () => { if (!state.stack.length) placeAt(bid, 0); },
    onHoldStart: (x, y) => { drag = beginDrag({ listEl: $('#stack-list'), srcEl: blk, x, y, reverse: true, external: true }); blk.style.visibility = 'hidden'; },
    onHoldMove: (x, y) => drag && drag.move(x, y),
    onHoldEnd: cancelled => {
      if (!drag) return;
      const idx = drag.end(); drag = null;
      if (cancelled) { blk.style.visibility = ''; return; }
      placeAt(bid, Math.max(0, idx));
    }
  });
}
function placeAt(bid, idx) {
  detach(bid);
  state.stack.splice(idx, 0, bid);
  save(); renderAll();
}

function renderRunbar() {
  const rb = $('#runbar');
  const show = !!state.running && !screens.some(s => s.classList.contains('start'));
  rb.classList.toggle('hidden', !show);
  if (!show) return;
  const r = state.running, rem = r.budget - sessionWorked(r);
  rb.innerHTML = `<span>${isPaused() ? 'Paused' : 'Running'}: ${esc(blockName(r.bid))}</span><span>${rem >= 0 ? fmtDur(rem) : '+' + fmtDur(-rem)}</span>`;
}

/* ---------- BACKLOG ---------- */
function renderBacklog() {
  backSel = backSel.filter(b => state.backlog.includes(b));
  const list = $('#backlog-list');
  list.innerHTML = '';
  state.backlog.forEach(bid => { const e = blockEl(bid); if (backSel.includes(bid)) e.classList.add('sel'); list.appendChild(e); });
  wireList(list, {
    reverse: false,
    enabled: () => backSel.length === 0,
    onReorder: keys => { state.backlog = keys; save(); },
    swipeRight: bid => { detach(bid); state.placing.push(bid); save(); goPanel('stack'); renderAll(); },
    swipeLeft: bid => backlogLeft(bid),
    tap: bid => { backSel = backSel.includes(bid) ? backSel.filter(b => b !== bid) : backSel.concat(bid); renderBacklog(); }
  });
  const add = $('#btn-add');
  add.classList.toggle('hidden', !backSel.length);
  add.textContent = backSel.length > 1 ? `ADD ${backSel.length}` : 'ADD';
  $('#backlog-empty').classList.toggle('hidden', !!state.backlog.length);
}
function backlogLeft(bid) {
  const b = state.blocks[bid], it = state.items[b.itemId];
  if (b.subId) withUndo('Returned to project', () => removeBlock(bid));
  else if (it.recurring) withUndo('Skipped until next time', () => removeBlock(bid));
  else withUndo('Deleted', () => deleteItem(it.id));
}
function addSelected() {
  backSel.forEach(bid => { detach(bid); state.placing.push(bid); });
  backSel = [];
  save(); goPanel('stack'); renderAll();
}

/* ---------- search / create ---------- */
function clearMainInput() { $('#main-input').value = ''; hideSuggest(); }
function hideSuggest() { const s = $('#suggest'); if (s) s.classList.add('hidden'); }
function showSuggest() {
  const inp = $('#main-input'), sug = $('#suggest');
  const raw = inp.value.trim(), v = raw.toLowerCase();
  let items = Object.values(state.items);
  if (v) items = items.filter(i => i.name.toLowerCase().includes(v));
  items.sort((a, b) => (a.name.toLowerCase().startsWith(v) ? 0 : 1) - (b.name.toLowerCase().startsWith(v) ? 0 : 1) || a.name.localeCompare(b.name));
  let html = '';
  if (raw && !itemByName(raw)) html += `<div class="sug create" data-new="1"><span class="tag">NEW</span><span>${esc(raw)}</span></div>`;
  html += items.slice(0, 60).map(i => `<div class="sug" data-id="${i.id}"><span class="tag">${TYPES[i.type]}</span><span>${esc(i.name)}</span></div>`).join('');
  if (!html) { hideSuggest(); return; }
  sug.innerHTML = html;
  sug.classList.remove('hidden');
}
function submitInput() {
  const inp = $('#main-input'), v = inp.value.trim();
  if (!v) return;
  const ex = itemByName(v);
  inp.blur(); hideSuggest();
  if (ex) { inp.value = ''; openEditor(ex, false); }
  else openChooser(v);
}

/* ---------- SETTINGS ---------- */
function renderSettings() {
  const body = $('#settings-body');
  if (!body || (document.activeElement && document.activeElement.id === 'cid')) return;
  const s = state.settings;
  const status = tokenValid() ? 'Connected' : s.connected ? 'Connected. Access refreshes on your next sync.' : 'Not connected';
  body.innerHTML = `
    <div class="sect"><h3>Google</h3>
      <p>Paste the OAuth client ID from your Google Cloud project. The README walks through setup.</p>
      <input type="text" id="cid" placeholder="Client ID" autocomplete="off" spellcheck="false">
      <p class="status">${esc(status)}</p>
      <button class="btn wide" id="b-connect">CONNECT GOOGLE</button>
    </div>
    <div class="sect"><h3>Drive backup</h3>
      <p>Backs up automatically after changes while connected. Last backup: ${s.lastBackup ? esc(new Date(s.lastBackup).toLocaleString()) : 'never'}.</p>
      <div class="btnrow"><button class="btn" id="b-backup">BACK UP NOW</button><button class="btn quiet" id="b-restore">RESTORE</button></div>
    </div>
    <div class="sect"><h3>File backup</h3>
      <p>Save or load a copy of everything as a file on this phone.</p>
      <div class="btnrow"><button class="btn" id="b-export">EXPORT</button><button class="btn quiet" id="b-import">IMPORT</button></div>
      <input type="file" id="f-import" accept="application/json,.json" class="hidden">
    </div>
    <div class="sect"><h3>Install</h3>
      <p>In Chrome, open the menu and choose Add to home screen (or Install app) to run Paradigm fullscreen.</p>
      <p>Paradigm ${VERSION}</p>
    </div>`;
  const cid = $('#cid');
  cid.value = s.clientId || '';
  cid.addEventListener('change', () => { s.clientId = cid.value.trim(); tokenClient = null; save({ noBackup: true }); });
  $('#b-connect').addEventListener('click', () => {
    s.clientId = cid.value.trim(); save({ noBackup: true });
    if (!s.clientId) return toast('Paste your client ID first');
    if (!gisReady()) return toast('Google sign-in did not load. Check your connection and reopen the app.');
    getToken(true, true).then(tok => {
      toast(tok ? 'Connected to Google' : 'Could not connect. Check the client ID and that you are a test user.');
      if (tok) driveBackup();
      renderSettings();
    });
  });
  $('#b-backup').addEventListener('click', () => {
    const tp = getToken(true);
    driveBackup(tp).then(ok => toast(ok ? 'Backed up to Drive' : 'Backup failed. Connect Google first.'));
  });
  $('#b-restore').addEventListener('click', () => confirmBox('Replace everything on this phone with your Drive backup?', 'RESTORE', () => {
    const tp = getToken(true);
    driveRestore(tp).then(data => { applyImport(data); toast('Restored from Drive'); }).catch(e => toast(e.message));
  }));
  $('#b-export').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(exportable(), null, 1)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = `paradigm-${todayStr()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  });
  const fin = $('#f-import');
  $('#b-import').addEventListener('click', () => fin.click());
  fin.addEventListener('change', async () => {
    const f = fin.files[0]; if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      if (!data.items) throw new Error('bad');
      confirmBox('Replace everything on this phone with this file?', 'IMPORT', () => { applyImport(data); toast('Imported'); });
    } catch (e) { toast('That file is not a Paradigm backup'); }
    fin.value = '';
  });
}
function applyImport(data) {
  const auth = state.auth, settings = state.settings;
  state = normalize(data);
  state.auth = auth;
  state.settings = Object.assign({}, settings, { clientId: settings.clientId || (data.settings && data.settings.clientId) || '' });
  backSel = [];
  repair(); save(); renderAll();
}

/* ---------- due items + clock ---------- */
function flashArrivals(bids) {
  if (!bids || !bids.length) return;
  requestAnimationFrame(() => bids.forEach(bid => {
    const e = $(`#stack-list [data-key="${bid}"]`);
    if (e) { e.classList.add('flash'); setTimeout(() => e.classList.remove('flash'), 1000); }
  }));
}
function checkDue() {
  if (state.lastDueCheck >= todayStr() || dragCtx) return;
  const arrived = runDueCheck();
  renderAll(); flashArrivals(arrived);
}

/* ---------- boot ---------- */
async function boot() {
  history.replaceState({ d: 0 }, '');
  try { await loadState(); }
  catch (e) { state = freshState(); toast('Storage is unavailable. Changes will not be kept.'); }

  gesture($('#t-stack'), { moveEl: false, onSwipeRight: () => goPanel('backlog'), onSwipeLeft: () => goPanel('settings') });
  gesture($('#t-backlog'), { moveEl: false, onSwipeLeft: () => goPanel('stack') });
  gesture($('#t-settings'), { moveEl: false, onSwipeRight: () => goPanel('stack') });
  $('#btn-add').addEventListener('click', addSelected);
  $('#runbar').addEventListener('click', openStart);

  const inp = $('#main-input'), sug = $('#suggest');
  inp.addEventListener('focus', showSuggest);
  inp.addEventListener('input', showSuggest);
  inp.addEventListener('blur', () => setTimeout(hideSuggest, 180));
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); submitInput(); } });
  sug.addEventListener('mousedown', e => e.preventDefault());
  sug.addEventListener('click', e => {
    const r = e.target.closest('.sug'); if (!r) return;
    if (r.dataset.new) { const v = inp.value.trim(); inp.blur(); hideSuggest(); openChooser(v); }
    else { const it = state.items[r.dataset.id]; inp.value = ''; inp.blur(); hideSuggest(); if (it) openEditor(it, false); }
  });

  const arrived = runDueCheck();
  renderAll();
  flashArrivals(arrived);
  if (state.running) openStart();

  setInterval(() => { renderRunbar(); checkDue(); }, 1000);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) flush();
    else { checkDue(); renderRunbar(); }
  });
  window.addEventListener('pagehide', flush);
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
}
boot();
