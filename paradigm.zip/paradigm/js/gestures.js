/* Paradigm: touch gestures.
   hold ~300ms = pick up and drag; quick horizontal flick = swipe; vertical flick = scroll (or swipe up/down where enabled). */
'use strict';

const HOLD_MS = 300, SLOP = 10, SWIPE_DIST = 80;

function gesture(el, o) {
  let st = null;
  const hasH = () => !!(o.onSwipeLeft || o.onSwipeRight);
  const hasV = () => !!(o.onSwipeUp || o.onSwipeDown);
  const mover = () => o.moveEl === false ? null : (o.moveEl || el);

  el.addEventListener('touchstart', e => {
    if (e.touches.length > 1) { cancel(); return; }
    if (o.ignore && o.ignore(e.target)) { st = null; return; }
    const en = !o.enabled || o.enabled();
    const t = e.touches[0];
    st = { x: t.clientX, y: t.clientY, t: Date.now(), mode: null, dx: 0, dy: 0, tapOnly: !en };
    if (o.onHoldStart && en) {
      st.timer = setTimeout(() => {
        if (st && !st.mode) {
          st.mode = 'hold';
          if (navigator.vibrate) navigator.vibrate(12);
          o.onHoldStart(st.x, st.y);
        }
      }, HOLD_MS);
    }
  }, { passive: true });

  el.addEventListener('touchmove', e => {
    if (!st) return;
    const t = e.touches[0];
    const dx = t.clientX - st.x, dy = t.clientY - st.y;
    st.dx = dx; st.dy = dy; st.cx = t.clientX; st.cy = t.clientY;
    if (st.mode === 'hold') { if (e.cancelable) e.preventDefault(); o.onHoldMove && o.onHoldMove(t.clientX, t.clientY); return; }
    if (!st.mode) {
      if (Math.abs(dx) < SLOP && Math.abs(dy) < SLOP) return;
      clearTimeout(st.timer);
      if (st.tapOnly) st.mode = 'scroll';
      else if (Math.abs(dx) > Math.abs(dy) && hasH()) st.mode = 'h';
      else if (Math.abs(dy) >= Math.abs(dx) && hasV()) st.mode = 'v';
      else st.mode = 'scroll';
    }
    if (st.mode === 'h') {
      if (e.cancelable) e.preventDefault();
      const m = mover(); if (m) { m.style.transition = 'none'; m.style.transform = `translateX(${dx}px)`; }
    } else if (st.mode === 'v') {
      if (e.cancelable) e.preventDefault();
    }
  }, { passive: false });

  function snapBack() {
    const m = mover(); if (!m) return;
    m.style.transition = 'transform .18s ease-out'; m.style.transform = '';
  }
  function fly(dir, cb) {
    const m = mover();
    if (!m || o.noFly) { if (m) { m.style.transition = ''; m.style.transform = ''; } cb(); return; }
    m.style.transition = 'transform .15s ease-in';
    m.style.transform = `translateX(${dir * window.innerWidth}px)`;
    setTimeout(() => { cb(); requestAnimationFrame(() => { if (m.isConnected) { m.style.transition = 'none'; m.style.transform = ''; } }); }, 150);
  }
  function cancel() {
    if (!st) return;
    clearTimeout(st.timer);
    if (st.mode === 'hold') o.onHoldEnd && o.onHoldEnd(true);
    if (st.mode === 'h') snapBack();
    st = null;
  }

  el.addEventListener('touchend', e => {
    if (!st) return;
    clearTimeout(st.timer);
    const s = st; st = null;
    if (s.mode === 'hold') { o.onHoldEnd && o.onHoldEnd(false); return; }
    if (s.mode === 'h') {
      const fast = Math.abs(s.dx) > 40 && Date.now() - s.t < 260;
      if (Math.abs(s.dx) > SWIPE_DIST || fast) {
        if (s.dx > 0 && o.onSwipeRight) return fly(1, o.onSwipeRight);
        if (s.dx < 0 && o.onSwipeLeft) return fly(-1, o.onSwipeLeft);
      }
      snapBack(); return;
    }
    if (s.mode === 'v') {
      if (s.dy < -60 && o.onSwipeUp) o.onSwipeUp();
      else if (s.dy > 60 && o.onSwipeDown) o.onSwipeDown();
      return;
    }
    if (!s.mode && Date.now() - s.t < 450 && o.onTap) { o.onTap(e); }
  });
  el.addEventListener('touchcancel', cancel);
  el.addEventListener('contextmenu', e => e.preventDefault());

  // Mouse fallback for desktop testing: click = tap.
  if (o.onTap) el.addEventListener('click', e => { if (!('ontouchstart' in window)) o.onTap(e); });
}

/* ---------- drag-to-sort ----------
   listEl: container of .block children. reverse: true when the list is column-reverse (index 0 at the bottom).
   srcEl: the element being dragged (already in listEl), or a detached element when placing a new block. */
let dragCtx = null;
function beginDrag({ listEl, srcEl, x, y, reverse, external }) {
  const r = srcEl.getBoundingClientRect();
  const ghost = srcEl.cloneNode(true);
  ghost.classList.add('ghost');
  ghost.classList.remove('ph');
  ghost.style.width = r.width + 'px';
  ghost.style.left = r.left + 'px';
  const offY = y - r.top;
  ghost.style.top = (y - offY) + 'px';
  document.getElementById('ghost-layer').appendChild(ghost);

  let ph = srcEl;
  if (external) { ph = document.createElement('div'); ph.className = 'block ph'; ph.innerHTML = srcEl.innerHTML; listEl.appendChild(ph); }
  ph.classList.add('ph');

  let scrollTimer = null, lastY = y;
  function place(cy) {
    const sibs = [...listEl.children].filter(c => c !== ph && c.classList.contains('block'));
    let idx = 0;
    for (const s of sibs) {
      const b = s.getBoundingClientRect(), mid = b.top + b.height / 2;
      if (reverse ? mid > cy : mid < cy) idx++;
    }
    const ref = sibs[idx] || null;
    if (ref) { if (ph.nextSibling !== ref) listEl.insertBefore(ph, ref); }
    else if (listEl.lastElementChild !== ph) listEl.appendChild(ph);
  }
  function autoscroll() {
    const lr = listEl.getBoundingClientRect();
    let v = 0;
    if (lastY < lr.top + 50) v = -12; else if (lastY > lr.bottom - 50) v = 12;
    if (v) { listEl.scrollTop += v; place(lastY); }
  }
  scrollTimer = setInterval(autoscroll, 30);
  place(y);

  dragCtx = {
    move(cx, cy) { lastY = cy; ghost.style.top = (cy - offY) + 'px'; place(cy); },
    end() {
      clearInterval(scrollTimer);
      ghost.remove();
      const idx = [...listEl.children].filter(c => c.classList.contains('block')).indexOf(ph);
      if (external) ph.remove(); else ph.classList.remove('ph');
      dragCtx = null;
      return idx;
    }
  };
  return dragCtx;
}

/* Wires a rendered list: each child .block with data-key gets swipe/hold/tap per opts.
   opts: { reverse, keys:[...] in data order, onReorder(newKeys), swipeRight(key), swipeLeft(key), tap(key), enabled() } */
function wireList(listEl, opts) {
  [...listEl.children].forEach(el => {
    if (!el.classList.contains('block')) return;
    const key = el.dataset.key;
    let drag = null;
    gesture(el, {
      enabled: opts.enabled,
      onSwipeRight: opts.swipeRight ? () => opts.swipeRight(key) : null,
      onSwipeLeft: opts.swipeLeft ? () => opts.swipeLeft(key) : null,
      onTap: opts.tap ? () => opts.tap(key) : null,
      onHoldStart: opts.onReorder ? (x, y) => { drag = beginDrag({ listEl, srcEl: el, x, y, reverse: opts.reverse }); } : null,
      onHoldMove: (x, y) => drag && drag.move(x, y),
      onHoldEnd: () => {
        if (!drag) return;
        drag.end(); drag = null;
        const keys = [...listEl.children].filter(c => c.classList.contains('block')).map(c => c.dataset.key);
        opts.onReorder(keys);
      }
    });
  });
}
