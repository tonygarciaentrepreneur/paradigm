/* Paradigm: overlay screens */
'use strict';

const $ = (s, r) => (r || document).querySelector(s);
const screens = [];
let afterPop = null;

/* ---------- screen stack (Android back closes the top screen) ---------- */
function screenEl(cls, html) { const el = document.createElement('div'); el.className = 'screen ' + cls; el.innerHTML = html; return el; }
function openScreen(el) { $('#overlays').appendChild(el); screens.push(el); history.pushState({ d: screens.length }, ''); hideSuggest(); hideToast(); }
function closeN(n, then) {
  n = Math.min(n, screens.length);
  if (!n) { if (then) then(); return; }
  afterPop = then || null;
  history.go(-n);
}
const closeTop = then => closeN(1, then);
const closeAll = then => closeN(screens.length, then);
window.addEventListener('popstate', e => {
  const d = (e.state && e.state.d) || 0;
  while (screens.length > d) { const el = screens.pop(); el.remove(); if (el._onClose) el._onClose(); }
  const f = afterPop; afterPop = null;
  renderAll();
  if (f) f();
});
function backBtn(el) { el.querySelector('.back').addEventListener('click', () => closeTop()); }

/* ---------- toast, undo, confirm ---------- */
let toastTimer = null;
function toast(msg, action) {
  const t = $('#toast');
  t.innerHTML = `<span>${esc(msg)}</span>`;
  if (action) {
    const a = document.createElement(action.href ? 'a' : 'button');
    a.className = 'btn act'; a.textContent = action.label;
    if (action.href) { a.href = action.href; a.target = '_blank'; a.rel = 'noopener'; }
    a.addEventListener('click', () => { hideToast(); if (action.fn) action.fn(); });
    t.appendChild(a);
  }
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, action && action.href ? 12000 : 5000);
}
function hideToast() { $('#toast').classList.add('hidden'); }
function withUndo(msg, mutate) {
  const snap = JSON.stringify(state);
  mutate(); save(); renderAll();
  toast(msg, { label: 'UNDO', fn: () => {
    const auth = state.auth, settings = state.settings;
    state = JSON.parse(snap); state.auth = auth; state.settings = settings;
    save(); renderAll();
  } });
}
function confirmBox(msg, okLabel, onOk) {
  const m = document.createElement('div');
  m.className = 'modal';
  m.innerHTML = `<div class="box"><div class="msg">${esc(msg)}</div><div class="btnrow"><button class="btn quiet c">CANCEL</button><button class="btn primary o">${esc(okLabel)}</button></div></div>`;
  $('.c', m).onclick = () => m.remove();
  $('.o', m).onclick = () => { m.remove(); onOk(); };
  document.body.appendChild(m);
}
function calFallbackToast(msg, name, ev, details) {
  toast(msg, { label: 'ADD TO CALENDAR', href: calLink(name, ev, details) });
}

/* ---------- chooser ---------- */
function openChooser(name) {
  const el = screenEl('chooser-screen', `
    <div class="bar"><button class="back" aria-label="Back">‹</button></div>
    <div class="chooser">
      <div class="q"></div>
      <button class="btn" data-t="task">TASK</button>
      <button class="btn" data-t="list">LIST</button>
      <button class="btn" data-t="event">EVENT</button>
      <button class="btn" data-t="project">PROJECT</button>
    </div>`);
  $('.q', el).textContent = name;
  backBtn(el);
  el.querySelectorAll('[data-t]').forEach(b => b.addEventListener('click', () => chooseType(b.dataset.t, name)));
  openScreen(el);
}
function chooseType(t, name) {
  if (t === 'task') {
    const it = newItem('task', name);
    state.items[it.id] = it;
    queueForStack(it.id, null);
    save(); clearMainInput();
    closeAll(() => goPanel('stack'));
  } else if (t === 'event') {
    openMonth({ title: name, onPick: date => openDay({ mode: 'event', date, name, sel: null, onSave: ev => {
      const tp = getToken(true);
      const it = newItem('event', name);
      it.event = ev;
      state.items[it.id] = it;
      save(); clearMainInput();
      closeAll(() => { goPanel('stack'); toast('Event saved'); setTimeout(() => sync()); });
      const sync = () => tp.then(async tok => {
        if (!tok) return calFallbackToast('Google is not connected.', it.name, ev);
        try { it.event.gcalId = await calInsertEvent(tok, it.name, it.event); save(); toast('Added to Google Calendar'); }
        catch (e) { calFallbackToast('Could not reach Google Calendar.', it.name, ev); }
      });
    } }) });
  } else {
    openEditor(newItem(t, name), true);
  }
}

/* ---------- editors ---------- */
function eventWhen(ev) {
  if (!ev) return 'No time set';
  const d = parseDate(ev.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  return ev.allDay ? `${d}, all day` : `${d}, ${minToClock(ev.startMin)} to ${minToClock(ev.endMin)}`;
}

function openEditor(item, isNew) {
  const orig = clone(item);
  const d = clone(item);
  let selMode = false, selected = [];
  const el = screenEl('editor', `
    <div class="bar"><button class="back" aria-label="Back">‹</button><span class="label">${TYPES[d.type]}</span></div>
    <div class="body"><input class="namein" type="text" autocomplete="off"><div class="content"></div></div>
    <div class="foot"></div>`);
  backBtn(el);
  const nameIn = $('.namein', el);
  nameIn.value = d.name;
  nameIn.addEventListener('input', () => { d.name = nameIn.value; });
  const content = $('.content', el), foot = $('.foot', el);
  let subsList = null;

  function render() {
    content.innerHTML = '';
    if (d.type === 'task') {
      const s = document.createElement('div'); s.className = 'sect';
      s.innerHTML = '<h3>Notes</h3><textarea class="notes" placeholder="Anything to remember"></textarea>';
      const ta = $('textarea', s); ta.value = d.notes || ''; ta.addEventListener('input', () => { d.notes = ta.value; });
      content.appendChild(s);
      const r = document.createElement('div'); r.className = 'sect'; content.appendChild(r); recurringUI(d, r);
    }
    if (d.type === 'list') {
      const r = document.createElement('div'); r.className = 'sect'; content.appendChild(r); recurringUI(d, r);
    }
    if (d.type === 'list' || d.type === 'project') {
      const s = document.createElement('div'); s.className = 'sect editor-list';
      s.innerHTML = `<h3>${selMode ? 'Tap subtasks to add to STACK' : 'Subtasks'}</h3><div class="list rev"></div>${selMode ? '' : '<input class="subin" type="text" placeholder="Add a subtask" enterkeyhint="done" autocomplete="off">'}`;
      content.appendChild(s);
      subsList = $('.list', s);
      const si = $('.subin', s);
      if (si) si.addEventListener('keydown', e => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const v = si.value.trim(); if (!v) return;
        d.subtasks.push({ id: uid(), name: v, done: false });
        si.value = ''; renderSubs();
      });
      renderSubs();
    }
    if (d.type === 'event') {
      const s = document.createElement('div'); s.className = 'sect';
      s.innerHTML = `<h3>When</h3><p class="status"></p><button class="btn wide">CHANGE TIME</button>`;
      $('.status', s).textContent = eventWhen(d.event);
      $('button', s).addEventListener('click', changeTime);
      content.appendChild(s);
    }
    renderFoot();
  }

  function renderSubs() {
    if (!subsList) return;
    subsList.innerHTML = '';
    d.subtasks.forEach(s => {
      const b = document.createElement('div');
      b.className = 'block small' + (s.done ? ' done' : '') + (selMode && selected.includes(s.id) ? ' sel' : '');
      b.dataset.key = s.id;
      let extra = '';
      if (d.type === 'project') {
        const bid = findBlock(d.id, s.id), w = bid && whereBlock(bid);
        if (w) extra = `<span class="onstack">${w === 'backlog' ? 'BACKLOG' : w === 'running' ? 'RUNNING' : 'STACK'}</span>`;
      }
      b.innerHTML = `<span class="name">${esc(s.name)}</span>${extra}`;
      subsList.appendChild(b);
    });
    wireList(subsList, {
      reverse: true,
      onReorder: selMode ? null : keys => { d.subtasks = keys.map(k => d.subtasks.find(s => s.id === k)); renderSubs(); },
      swipeLeft: selMode ? null : k => { d.subtasks = d.subtasks.filter(s => s.id !== k); renderSubs(); },
      tap: k => {
        const s = d.subtasks.find(x => x.id === k); if (!s) return;
        if (selMode) {
          if (s.done) return;
          selected = selected.includes(k) ? selected.filter(x => x !== k) : selected.concat(k);
          renderSubs(); renderFoot();
        } else { s.done = !s.done; renderSubs(); }
      }
    });
  }

  function renderFoot() {
    foot.innerHTML = '';
    const row = document.createElement('div'); row.className = 'btnrow';
    const mk = (label, cls, fn) => { const b = document.createElement('button'); b.className = 'btn ' + (cls || ''); b.textContent = label; b.addEventListener('click', fn); return b; };
    if (selMode) {
      row.append(mk('CANCEL', 'quiet', () => { selMode = false; selected = []; render(); }));
      const add = mk(selected.length ? `ADD ${selected.length} TO STACK` : 'ADD TO STACK', 'primary', addProjectSubs);
      add.disabled = !selected.length;
      row.append(add); foot.append(row); return;
    }
    if (!isNew) row.append(mk('DELETE', 'danger', del));
    row.append(mk('SAVE', '', onSave));
    foot.append(row);
    if (d.type !== 'event') foot.append(mk('ADD TO STACK', 'primary wide', onAdd));
  }

  function validName() {
    const n = (d.name || '').trim();
    if (!n) { toast('Give it a name first'); return false; }
    const other = itemByName(n);
    if (other && other.id !== d.id) { toast('Another item already has that name'); return false; }
    d.name = n; return true;
  }
  function commit() {
    if (d.type === 'project') {
      const keep = new Set(d.subtasks.map(s => s.id));
      for (const bid of Object.keys(state.blocks)) { const b = state.blocks[bid]; if (b.itemId === d.id && b.subId && !keep.has(b.subId)) removeBlock(bid); }
    }
    state.items[d.id] = d;
    save();
  }
  function onSave() {
    if (!validName()) return;
    if (d.type === 'event') return saveEvent();
    commit(); clearMainInput();
    closeAll(() => { goPanel('stack'); toast('Saved'); });
  }
  function onAdd() {
    if (!validName()) return;
    if (d.type === 'project') {
      if (!d.subtasks.some(s => !s.done)) { toast('Add a subtask first'); return; }
      selMode = true; selected = []; render(); return;
    }
    commit(); clearMainInput();
    const msg = queueForStack(d.id, null); save();
    closeAll(() => { goPanel('stack'); if (msg) toast(msg); });
  }
  function addProjectSubs() {
    if (!validName()) return;
    commit(); clearMainInput();
    const msgs = selected.map(sid => queueForStack(d.id, sid)).filter(Boolean);
    save();
    closeAll(() => { goPanel('stack'); if (msgs.length) toast('Some subtasks were already on STACK'); });
  }
  function del() {
    const msg = d.type === 'project' ? `Delete project “${orig.name}” and remove its subtasks from STACK and BACKLOG?` : `Delete “${orig.name}”?`;
    confirmBox(msg, 'DELETE', () => {
      const gid = orig.type === 'event' && orig.event && orig.event.gcalId;
      const tp = gid ? getToken(true) : null;
      deleteItem(d.id); save(); clearMainInput();
      closeAll(() => { goPanel('stack'); toast('Deleted'); if (tp) setTimeout(() => sync()); });
      const sync = () => tp.then(async tok => {
        if (!tok) return toast('Google is not connected. Delete the event in Google Calendar too.');
        try { await calDeleteEvent(tok, gid); toast('Deleted from Google Calendar'); }
        catch (e) { toast('Could not reach Google Calendar. Delete the event there too.'); }
      });
    });
  }
  function changeTime() {
    openMonth({ title: d.name, picked: d.event && d.event.date, onPick: date => {
      const sel = d.event && d.event.date === date ? { allDay: d.event.allDay, startMin: d.event.startMin, endMin: d.event.endMin } : null;
      openDay({ mode: 'event', date, name: d.name, sel, onSave: ev => {
        d.event = Object.assign({}, ev, { gcalId: d.event && d.event.gcalId || '' });
        closeN(2, render);
      } });
    } });
  }
  function saveEvent() {
    if (!d.event) { toast('Pick a time first'); return; }
    const changed = JSON.stringify([orig.name, orig.event]) !== JSON.stringify([d.name, d.event]) || !d.event.gcalId;
    const tp = changed ? getToken(true) : null;
    commit(); clearMainInput();
    closeAll(() => { goPanel('stack'); toast('Saved'); if (tp) setTimeout(() => sync()); });
    const it = state.items[d.id];
    const sync = () => tp.then(async tok => {
      if (!tok) {
        if (it.event.gcalId) return toast('Google is not connected. Update the event in Google Calendar too.');
        return calFallbackToast('Google is not connected.', it.name, it.event);
      }
      try {
        if (it.event.gcalId) await calUpdateEvent(tok, it.event.gcalId, it.name, it.event);
        else { it.event.gcalId = await calInsertEvent(tok, it.name, it.event); save(); }
        toast('Google Calendar updated');
      } catch (e) {
        if (it.event.gcalId) toast('Could not reach Google Calendar. Update the event there too.');
        else calFallbackToast('Could not reach Google Calendar.', it.name, it.event);
      }
    });
  }

  render();
  openScreen(el);
}

/* ---------- recurring + schedule controls ---------- */
function checkBtn(label, on, fn) {
  const b = document.createElement('button');
  b.className = 'check' + (on ? ' on' : '');
  b.setAttribute('aria-pressed', on ? 'true' : 'false');
  b.innerHTML = `<span class="box"></span><span>${esc(label)}</span>`;
  b.addEventListener('click', fn);
  return b;
}
function recurringUI(d, host) {
  host.innerHTML = '';
  const again = () => recurringUI(d, host);
  if (d.type === 'task') {
    host.append(checkBtn('Recurring', d.recurring, () => { d.recurring = !d.recurring; again(); }));
    if (d.recurring) host.append(scheduleUI(d));
  } else if (d.type === 'list') {
    host.append(checkBtn('Recurring list', d.recurring, () => { d.recurring = !d.recurring; if (!d.recurring) d.recSubtasks = false; again(); }));
    if (d.recurring) {
      host.append(checkBtn('Recurring subtasks', d.recSubtasks, () => { d.recSubtasks = !d.recSubtasks; again(); }));
      host.append(scheduleUI(d));
    }
  }
}
function scheduleUI(d) {
  const w = document.createElement('div'); w.className = 'sect';
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function render() {
    const s = d.schedule = Object.assign(defaultSchedule('none'), d.schedule || {});
    w.innerHTML = `<h3>Repeats</h3><div class="seg f">${['none', 'daily', 'weekly', 'monthly', 'annually'].map(f => `<button data-f="${f}" class="${s.freq === f ? 'on' : ''}">${f.toUpperCase()}</button>`).join('')}</div><div class="extra"></div>`;
    w.querySelectorAll('[data-f]').forEach(b => b.addEventListener('click', () => { s.freq = b.dataset.f; render(); }));
    const x = $('.extra', w);
    if (s.freq === 'weekly') {
      x.innerHTML = `<div class="seg" style="margin-top:10px">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((l, i) => `<button data-d="${i}" aria-label="${['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][i]}" class="${s.days.includes(i) ? 'on' : ''}">${l}</button>`).join('')}</div>`;
      x.querySelectorAll('[data-d]').forEach(b => b.addEventListener('click', () => {
        const i = +b.dataset.d;
        s.days = s.days.includes(i) ? s.days.filter(v => v !== i) : s.days.concat(i);
        if (!s.days.length) s.days = [i];
        render();
      }));
    } else if (s.freq === 'monthly') {
      x.innerHTML = `<label class="inline">Day of month <input type="number" min="1" max="31" inputmode="numeric" value="${s.dom}"></label>`;
      $('input', x).addEventListener('change', e => { s.dom = Math.min(31, Math.max(1, parseInt(e.target.value, 10) || 1)); e.target.value = s.dom; });
    } else if (s.freq === 'annually') {
      x.innerHTML = `<div class="inline"><select>${MONTHS.map((m, i) => `<option value="${i}" ${i === s.month ? 'selected' : ''}>${m}</option>`).join('')}</select><input type="number" min="1" max="31" inputmode="numeric" value="${s.dom}"></div>`;
      $('select', x).addEventListener('change', e => { s.month = +e.target.value; });
      $('input', x).addEventListener('change', e => { s.dom = Math.min(31, Math.max(1, parseInt(e.target.value, 10) || 1)); e.target.value = s.dom; });
    }
  }
  render();
  return w;
}

/* ---------- month calendar ---------- */
function openMonth({ title, picked, onPick }) {
  const el = screenEl('monthscreen', `<div class="bar"><button class="back" aria-label="Back">‹</button><span class="label"></span></div><div class="months"></div>`);
  $('.label', el).textContent = title;
  backBtn(el);
  const box = $('.months', el), now = new Date(), today = todayStr();
  let html = '';
  for (let i = -1; i <= 24; i++) {
    const m = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const days = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
    let cells = '';
    for (let k = 0; k < m.getDay(); k++) cells += '<span></span>';
    for (let dd = 1; dd <= days; dd++) {
      const ds = dateStr(new Date(m.getFullYear(), m.getMonth(), dd));
      const cls = [ds < today ? 'past' : '', ds === today ? 'today' : '', ds === picked ? 'picked' : ''].join(' ');
      cells += `<button class="${cls}" data-date="${ds}">${dd}</button>`;
    }
    html += `<div class="month" ${i === 0 ? 'data-cur' : ''}><h2>${m.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }).toUpperCase()}</h2><div class="dow">${['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(x => `<span>${x}</span>`).join('')}</div><div class="days">${cells}</div></div>`;
  }
  box.innerHTML = html;
  box.addEventListener('click', e => { const b = e.target.closest('[data-date]'); if (b) onPick(b.dataset.date); });
  openScreen(el);
  requestAnimationFrame(() => { const c = $('[data-cur]', box); if (c) box.scrollTop = c.getBoundingClientRect().top - box.getBoundingClientRect().top - 8; });
}

/* ---------- day view: event time picker and START time block ---------- */
const SLOT_H = 32;
function openDay({ mode, date, name, sel, onSave, onStart }) {
  const isStart = mode === 'start';
  const el = screenEl('dayscreen', `
    <div class="bar"><button class="back" aria-label="Back">‹</button><span class="label"></span></div>
    <div class="dayhead"><span class="d"></span>${isStart ? '' : '<button class="check allday" style="width:auto"><span class="box"></span><span>All day</span></button>'}</div>
    <div class="allday-strip"></div>
    <div class="dayscroll"><div class="grid" style="margin-top:12px;margin-bottom:24px"></div></div>
    <div class="foot"><div class="selinfo"></div><button class="btn primary wide go">${isStart ? 'START' : 'SAVE'}</button></div>`);
  $('.label', el).textContent = name;
  $('.d', el).textContent = parseDate(date).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
  backBtn(el);
  const grid = $('.grid', el), scroller = $('.dayscroll', el), info = $('.selinfo', el), go = $('.go', el);
  let g = '';
  for (let i = 0; i < 48; i++) g += `<div class="slot ${i % 2 === 0 ? 'hr' : ''}"></div>`;
  for (let h = 0; h < 24; h++) g += `<span class="hlabel" style="top:${h * 2 * SLOT_H}px">${minToClock(h * 60).replace(':00', '')}</span>`;
  grid.innerHTML = g;
  const blk = document.createElement('div'); blk.className = 'selblk hidden'; grid.appendChild(blk);

  const nowD = new Date();
  const nowMin = nowD.getHours() * 60 + nowD.getMinutes() + nowD.getSeconds() / 60;
  if (date === todayStr()) { const nl = document.createElement('div'); nl.className = 'nowline'; nl.style.top = (nowMin / 30 * SLOT_H) + 'px'; grid.appendChild(nl); }

  let minEnd = 0;
  if (isStart) {
    const s = Math.floor(nowMin / 30) * 30;
    minEnd = Math.min(1440, Math.ceil((nowMin + 30) / 30) * 30);
    sel = { allDay: false, startMin: s, endMin: minEnd };
    const h = document.createElement('div'); h.className = 'handle'; h.setAttribute('aria-label', 'Drag to set end time'); blk.appendChild(h);
    const setEnd = y => { const r = grid.getBoundingClientRect(); sel.endMin = Math.max(minEnd, Math.min(1440, Math.round((y - r.top) / SLOT_H) * 30)); draw(); };
    h.addEventListener('touchstart', e => { e.stopPropagation(); }, { passive: true });
    h.addEventListener('touchmove', e => { if (e.cancelable) e.preventDefault(); const y = e.touches[0].clientY; edgeScroll(y); setEnd(y); }, { passive: false });
    gesture(grid, { moveEl: false, ignore: t => t.closest('.handle'), onTap: e => { const t = e.changedTouches ? e.changedTouches[0] : e; setEnd(t.clientY + SLOT_H / 2); } });
  } else {
    let anchor = 0;
    const slotAt = y => Math.max(0, Math.min(47, Math.floor((y - grid.getBoundingClientRect().top) / SLOT_H)));
    gesture(grid, {
      moveEl: false,
      enabled: () => !(sel && sel.allDay),
      onHoldStart: (x, y) => { anchor = slotAt(y); sel = { allDay: false, startMin: anchor * 30, endMin: anchor * 30 + 30 }; draw(); },
      onHoldMove: (x, y) => { edgeScroll(y); const s = slotAt(y), a = Math.min(anchor, s), b = Math.max(anchor, s); sel.startMin = a * 30; sel.endMin = (b + 1) * 30; draw(); },
      onHoldEnd: () => {},
      onTap: e => { const t = e.changedTouches ? e.changedTouches[0] : e; const s = slotAt(t.clientY); sel = { allDay: false, startMin: s * 30, endMin: s * 30 + 30 }; draw(); }
    });
    const ad = $('.allday', el);
    ad.addEventListener('click', () => {
      if (sel && sel.allDay) sel = null; else sel = { allDay: true, startMin: 0, endMin: 0 };
      draw();
    });
  }
  function edgeScroll(y) { const r = scroller.getBoundingClientRect(); if (y < r.top + 40) scroller.scrollTop -= 10; else if (y > r.bottom - 40) scroller.scrollTop += 10; }

  function draw() {
    const ad = $('.allday', el);
    if (ad) { ad.classList.toggle('on', !!(sel && sel.allDay)); }
    grid.classList.toggle('off', !!(sel && sel.allDay));
    if (!sel || sel.allDay) {
      blk.classList.add('hidden');
      info.textContent = sel && sel.allDay ? 'All day' : 'Hold and drag to pick a time';
      go.disabled = !sel; return;
    }
    blk.classList.remove('hidden');
    blk.style.top = (sel.startMin / 30 * SLOT_H) + 'px';
    blk.style.height = ((sel.endMin - sel.startMin) / 30 * SLOT_H) + 'px';
    const range = `${minToClock(sel.startMin)} to ${minToClock(sel.endMin % 1440)}`;
    if (blk.firstChild && blk.firstChild.nodeType === 3) blk.firstChild.textContent = range; else blk.insertBefore(document.createTextNode(range), blk.firstChild);
    if (isStart) {
      const mins = Math.max(1, Math.round(sel.endMin - (new Date().getHours() * 60 + new Date().getMinutes() + new Date().getSeconds() / 60)));
      info.textContent = `${range}, ${mins >= 60 ? Math.floor(mins / 60) + 'h ' + (mins % 60) + 'm' : mins + ' min'}`;
    } else info.textContent = range;
    go.disabled = false;
  }

  go.addEventListener('click', () => {
    if (!sel) return;
    if (isStart) onStart(parseDate(date).getTime() + sel.endMin * MIN);
    else onSave({ date, allDay: !!sel.allDay, startMin: sel.startMin, endMin: sel.endMin });
  });

  draw();
  openScreen(el);
  requestAnimationFrame(() => {
    const focusMin = sel && !sel.allDay ? sel.startMin : (date === todayStr() ? nowMin : 8 * 60);
    scroller.scrollTop = Math.max(0, focusMin / 30 * SLOT_H - 3 * SLOT_H);
  });

  calDayEvents(date).then(evs => {
    if (!evs || !el.isConnected) return;
    const strip = $('.allday-strip', el), t0 = parseDate(date).getTime();
    evs.forEach(e => {
      if (e.start && e.start.date) { const s = document.createElement('span'); s.textContent = e.summary || '(busy)'; strip.appendChild(s); return; }
      if (!e.start || !e.start.dateTime) return;
      const a = Math.max(0, (new Date(e.start.dateTime) - t0) / MIN), b = Math.min(1440, (new Date(e.end.dateTime) - t0) / MIN);
      if (b <= a) return;
      const d = document.createElement('div'); d.className = 'ev';
      d.style.top = (a / 30 * SLOT_H) + 'px'; d.style.height = Math.max(14, (b - a) / 30 * SLOT_H) + 'px';
      d.textContent = e.summary || '(busy)';
      grid.insertBefore(d, blk);
    });
  });
}

/* ---------- START screen ---------- */
const ICON_PAUSE = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="4" width="5" height="16"/><rect x="14" y="4" width="5" height="16"/></svg>';
const ICON_PLAY = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4 L20 12 L6 20 Z"/></svg>';
let startTick = null;

function openStartPicker(bid) {
  if (state.running) { toast('Finish or save the running item first'); openStart(); return; }
  openDay({ mode: 'start', date: todayStr(), name: blockName(bid), onStart: endMs => {
    startBlock(bid, endMs);
    closeAll(() => openStart());
  } });
}

function openStart() {
  const r = state.running; if (!r) return;
  if (screens.some(s => s.classList.contains('start'))) return;
  const b = state.blocks[r.bid], it = state.items[b.itemId];
  const isList = !b.subId && it.type === 'list';
  const notes = !b.subId && it.type === 'task' && (it.notes || '').trim();
  const hasDrawer = isList || !!notes;
  const C = 2 * Math.PI * 135;
  const el = screenEl('start', `
    <div class="bar"><button class="back" aria-label="Back to STACK">‹</button></div>
    <div class="stage">
      <div class="ringwrap">
        <svg viewBox="0 0 300 300"><circle class="ring-track" cx="150" cy="150" r="135"/><circle class="ring" cx="150" cy="150" r="135" stroke-dasharray="${C} ${C}"/></svg>
        <button class="pp" aria-label="Pause"></button>
      </div>
      <div class="minirow hidden"><div class="linebar"><i></i></div><button class="pp small" aria-label="Pause"></button></div>
      <div class="tclock"></div>
      <div class="tname"></div>
      <div class="thint"></div>
      ${hasDrawer ? `<div class="swipe-up-hint">Swipe up for ${isList ? 'subtasks' : 'notes'}</div>` : ''}
    </div>
    <div class="drawer"><div class="grab"></div>${isList ? '<div class="list rev"></div>' : notes ? '<div class="notesview"></div>' : ''}</div>`);
  $('.tname', el).textContent = blockName(r.bid);
  if (notes) $('.notesview', el).textContent = it.notes;
  backBtn(el);
  const ring = $('.ring', el), clock = $('.tclock', el), hint = $('.thint', el), bar = $('.linebar', el), barFill = $('.linebar i', el);
  const pps = el.querySelectorAll('.pp');
  pps.forEach(p => p.addEventListener('click', () => { if (isPaused()) resumeRunning(); else pauseRunning(); update(); }));

  function setOpen(open) {
    if (!hasDrawer) return;
    el.classList.toggle('open', open);
    if (isList) { $('.ringwrap', el).classList.toggle('hidden', open); $('.minirow', el).classList.toggle('hidden', !open); }
    const h = $('.swipe-up-hint', el); if (h) h.classList.toggle('hidden', open);
  }
  function renderSubs() {
    const list = $('.list', el); if (!list) return;
    const item = state.items[b.itemId]; if (!item) return;
    list.innerHTML = '';
    item.subtasks.forEach(s => {
      const d = document.createElement('div');
      d.className = 'block small' + (s.done ? ' done' : ''); d.dataset.key = s.id;
      d.innerHTML = `<span class="name">${esc(s.name)}</span>`;
      list.appendChild(d);
    });
    wireList(list, { reverse: true, tap: k => {
      const s = item.subtasks.find(x => x.id === k); if (!s) return;
      s.done = !s.done; save(); renderSubs();
      if (item.subtasks.length && item.subtasks.every(x => x.done) && state.running) {
        pauseRunning();
        hint.textContent = 'All done. Swipe right to complete, left to save.';
        update();
      }
    } });
  }
  renderSubs();

  gesture(el, {
    moveEl: false,
    ignore: t => !!t.closest('.pp, .back, .drawer .list, .notesview'),
    onSwipeRight: () => { if (isPaused()) doComplete(); },
    onSwipeLeft: () => { if (isPaused()) doSave(); },
    onSwipeUp: hasDrawer ? () => setOpen(true) : null,
    onSwipeDown: hasDrawer ? () => setOpen(false) : null
  });

  function update() {
    const rr = state.running; if (!rr) return;
    const worked = sessionWorked(rr), rem = rr.budget - worked, f = Math.max(0, Math.min(1, rem / rr.budget));
    const over = rem < 0;
    ring.setAttribute('stroke-dasharray', `${f * C} ${C}`);
    ring.classList.toggle('over', over);
    barFill.style.width = (f * 100) + '%';
    bar.classList.toggle('over', over);
    clock.textContent = over ? '+' + fmtDur(-rem) : fmtDur(rem);
    clock.classList.toggle('over', over);
    const paused = isPaused();
    pps.forEach(p => { p.innerHTML = paused ? ICON_PLAY : ICON_PAUSE; p.classList.toggle('paused', paused); p.setAttribute('aria-label', paused ? 'Resume' : 'Pause'); });
    if (paused) { if (!hint.textContent) hint.textContent = 'Swipe right to complete, left to save.'; }
    else hint.textContent = '';
    if (over && !paused && !rr.vibrated) { rr.vibrated = true; save(); if (navigator.vibrate) navigator.vibrate([400, 200, 400, 200, 400]); }
  }
  update();
  clearInterval(startTick);
  startTick = setInterval(update, 250);
  el._onClose = () => clearInterval(startTick);
  openScreen(el);
}
function doComplete() {
  const tp = getToken(true);
  const res = completeRunning();
  if (!res) return;
  closeAll(() => openSummary(res, tp));
}
function doSave() {
  saveRunning();
  closeAll(() => { goPanel('stack'); toast('Saved to BACKLOG'); });
}

/* ---------- completion summary ---------- */
function openSummary(res, tp) {
  const el = screenEl('sumscreen', `
    <div class="summary">
      <div class="sub">Complete</div>
      <div class="nm"></div>
      <div class="big">${fmtDur(res.total)}</div>
      <div class="sub">Logged ${msToClock(res.start)} to ${msToClock(res.end)}</div>
      <div class="sub status">Adding to your Paradigm calendar</div>
      <div class="fb"></div>
    </div>
    <div class="foot"><button class="btn primary wide done">DONE</button></div>`);
  $('.nm', el).textContent = res.name;
  $('.done', el).addEventListener('click', () => closeAll(() => goPanel('stack')));
  const status = $('.status', el), fb = $('.fb', el);
  const fail = msg => {
    status.textContent = msg;
    fb.innerHTML = '';
    const a = document.createElement('a');
    a.className = 'btn'; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'ADD TO CALENDAR';
    a.href = calLink(res.name, { startMs: res.start, endMs: res.end }, `Worked ${fmtDur(res.total)} in Paradigm`);
    fb.appendChild(a);
  };
  openScreen(el);
  tp.then(async tok => {
    if (!tok) return fail('Google is not connected.');
    try { await calLogCompletion(tok, res); status.textContent = 'Added to your Paradigm calendar'; }
    catch (e) { fail('Could not reach Google Calendar.'); }
  });
}
