/* Paradigm: state, persistence and model rules */
'use strict';

const MIN = 60000, HALF = 30 * MIN, DAY = 24 * 60 * MIN;
let state = null;
let idb = null;

/* ---------- small helpers ---------- */
const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const pad = n => String(n).padStart(2, '0');
function dateStr(d) { d = new Date(d); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
const todayStr = () => dateStr(Date.now());
function parseDate(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }
function addDays(s, n) { const d = parseDate(s); d.setDate(d.getDate() + n); return dateStr(d); }
function floor30(ms) { const d = new Date(ms); d.setSeconds(0, 0); d.setMinutes(d.getMinutes() < 30 ? 0 : 30); return d.getTime(); }
function ceilHalf(ms) { return Math.max(1, Math.ceil(ms / HALF)) * HALF; }
function minToClock(min) { const h = Math.floor(min / 60) % 24, m = min % 60; const ap = h < 12 ? 'AM' : 'PM'; const h12 = h % 12 || 12; return `${h12}:${pad(m)} ${ap}`; }
function msToClock(ms) { const d = new Date(ms); return minToClock(d.getHours() * 60 + d.getMinutes()); }
function fmtDur(ms) { ms = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(ms / 3600), m = Math.floor(ms % 3600 / 60), s = ms % 60; return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`; }
function fmtShort(ms) { const m = Math.round(ms / MIN); return m >= 60 ? `${Math.floor(m / 60)}h${m % 60 ? pad(m % 60) : ''}` : `${m}m`; }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
const clone = o => JSON.parse(JSON.stringify(o));

/* ---------- persistence (IndexedDB) ---------- */
function idbOpen() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('paradigm', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
function idbGet(k) {
  return new Promise((res, rej) => {
    const q = idb.transaction('kv').objectStore('kv').get(k);
    q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error);
  });
}
function idbSet(k, v) {
  return new Promise((res, rej) => {
    const t = idb.transaction('kv', 'readwrite');
    t.objectStore('kv').put(v, k);
    t.oncomplete = () => res(); t.onerror = () => rej(t.error);
  });
}

function freshState() {
  return {
    v: 1, items: {}, blocks: {}, stack: [], backlog: [], placing: [], running: null,
    lastDueCheck: todayStr(),
    settings: { clientId: '', connected: false, paradigmCalId: '', driveFileId: '', lastBackup: 0 },
    auth: { token: '', exp: 0 }
  };
}
function normalize(s) {
  const f = freshState();
  for (const k of Object.keys(f)) if (s[k] === undefined) s[k] = f[k];
  s.settings = Object.assign(f.settings, s.settings || {});
  s.auth = Object.assign(f.auth, s.auth || {});
  return s;
}

let saveTimer = null;
function save(opts) {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flush, 200);
  if (!(opts && opts.noBackup) && typeof scheduleBackup === 'function') scheduleBackup();
}
function flush() { clearTimeout(saveTimer); if (idb && state) return idbSet('state', state).catch(e => console.error(e)); }

async function loadState() {
  idb = await idbOpen();
  const s = await idbGet('state');
  state = normalize(s || freshState());
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
  repair();
}

/* Keep lists consistent: drop dead blocks, rescue orphans into the backlog. */
function repair() {
  const seen = new Set();
  const clean = arr => arr.filter(b => {
    const ok = state.blocks[b] && state.items[state.blocks[b].itemId] && !seen.has(b);
    if (ok) seen.add(b); return ok;
  });
  if (state.running && !(state.blocks[state.running.bid] && state.items[state.blocks[state.running.bid].itemId])) state.running = null;
  if (state.running) seen.add(state.running.bid);
  state.stack = clean(state.stack); state.backlog = clean(state.backlog); state.placing = clean(state.placing);
  for (const [bid, b] of Object.entries(state.blocks)) {
    const it = state.items[b.itemId];
    if (!it || (b.subId && !(it.subtasks || []).some(s => s.id === b.subId))) { delete state.blocks[bid]; continue; }
    if (!seen.has(bid)) state.backlog.push(bid);
  }
}

/* ---------- model queries ---------- */
const TYPES = { task: 'TASK', list: 'LIST', event: 'EVENT', project: 'PROJECT' };
function itemByName(name) {
  const n = name.trim().toLowerCase();
  return Object.values(state.items).find(i => i.name.trim().toLowerCase() === n) || null;
}
function findBlock(itemId, subId) {
  return Object.keys(state.blocks).find(b => state.blocks[b].itemId === itemId && (state.blocks[b].subId || null) === (subId || null)) || null;
}
function whereBlock(bid) {
  if (state.running && state.running.bid === bid) return 'running';
  if (state.stack.includes(bid)) return 'stack';
  if (state.backlog.includes(bid)) return 'backlog';
  if (state.placing.includes(bid)) return 'placing';
  return null;
}
function detach(bid) {
  state.stack = state.stack.filter(b => b !== bid);
  state.backlog = state.backlog.filter(b => b !== bid);
  state.placing = state.placing.filter(b => b !== bid);
}
function removeBlock(bid) {
  detach(bid);
  if (state.running && state.running.bid === bid) state.running = null;
  delete state.blocks[bid];
}
function blockLabel(bid) {
  const b = state.blocks[bid], it = state.items[b.itemId];
  if (b.subId) { const s = it.subtasks.find(x => x.id === b.subId); return { proj: it.name, name: s ? s.name : '?' }; }
  return { proj: null, name: it.name };
}
function blockName(bid) { const l = blockLabel(bid); return l.proj ? `${l.proj} › ${l.name}` : l.name; }

function newItem(type, name) {
  const it = { id: uid(), type, name: name.trim(), created: Date.now() };
  if (type === 'task') Object.assign(it, { notes: '', recurring: false, schedule: { freq: 'none' } });
  if (type === 'list') Object.assign(it, { subtasks: [], recurring: false, recSubtasks: false, schedule: { freq: 'none' } });
  if (type === 'project') Object.assign(it, { subtasks: [] });
  if (type === 'event') Object.assign(it, { event: null });
  return it;
}
function deleteItem(id) {
  for (const bid of Object.keys(state.blocks)) if (state.blocks[bid].itemId === id) removeBlock(bid);
  delete state.items[id];
}

/* Queue an item (or project subtask) for the placement step. Returns a message or null. */
function queueForStack(itemId, subId) {
  let bid = findBlock(itemId, subId);
  const w = bid && whereBlock(bid);
  if (w === 'stack') return 'Already on STACK';
  if (w === 'running') return 'Already running';
  if (w === 'placing') return null;
  if (w === 'backlog') detach(bid);
  if (!bid) { bid = uid(); state.blocks[bid] = { bid, itemId, subId: subId || null, elapsed: 0 }; }
  state.placing.push(bid);
  return null;
}

/* ---------- schedules ---------- */
function defaultSchedule(freq) {
  const d = new Date();
  return { freq, days: [d.getDay()], dom: d.getDate(), month: d.getMonth() };
}
function matchesSchedule(sch, d) {
  if (!sch || sch.freq === 'none') return false;
  const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  switch (sch.freq) {
    case 'daily': return true;
    case 'weekly': return (sch.days || []).includes(d.getDay());
    case 'monthly': return d.getDate() === Math.min(sch.dom || 1, dim);
    case 'annually': return d.getMonth() === sch.month && d.getDate() === Math.min(sch.dom || 1, dim);
  }
  return false;
}
/* Drops due recurring items onto the bottom of STACK. Returns ids that arrived. */
function runDueCheck() {
  const today = todayStr();
  if (state.lastDueCheck >= today) return [];
  const due = [];
  for (const it of Object.values(state.items)) {
    if (!it.recurring || !it.schedule || it.schedule.freq === 'none') continue;
    let d = addDays(state.lastDueCheck, 1), n = 0;
    while (d <= today && n++ < 400) { if (matchesSchedule(it.schedule, parseDate(d))) { due.push(it); break; } d = addDays(d, 1); }
  }
  state.lastDueCheck = today;
  due.sort((a, b) => b.created - a.created);
  const arrived = [];
  for (const it of due) {
    let bid = findBlock(it.id, null);
    const w = bid && whereBlock(bid);
    if (w === 'stack' || w === 'running' || w === 'placing') continue;
    if (w === 'backlog') detach(bid);
    if (!bid) { bid = uid(); state.blocks[bid] = { bid, itemId: it.id, subId: null, elapsed: 0 }; }
    state.stack.unshift(bid);
    arrived.push(bid);
  }
  if (due.length || arrived.length) save();
  return arrived;
}

/* ---------- timer ---------- */
function startBlock(bid, plannedEnd) {
  const now = Date.now();
  detach(bid);
  state.running = { bid, sessionStart: now, segStart: now, accum: 0, prior: state.blocks[bid].elapsed || 0, budget: Math.max(MIN, plannedEnd - now), vibrated: false };
  save();
}
function sessionWorked(r) { return r.accum + (r.segStart ? Date.now() - r.segStart : 0); }
function isPaused() { return state.running && !state.running.segStart; }
function pauseRunning() { const r = state.running; if (!r || !r.segStart) return; r.accum += Date.now() - r.segStart; r.segStart = null; save(); }
function resumeRunning() { const r = state.running; if (!r || r.segStart) return; r.segStart = Date.now(); save(); }

function saveRunning() {
  const r = state.running; if (!r) return;
  pauseRunning();
  state.blocks[r.bid].elapsed = r.prior + r.accum;
  state.backlog.unshift(r.bid);
  state.running = null;
  save();
}
/* Completes the running block; returns the summary used for the calendar entry. */
function completeRunning() {
  const r = state.running; if (!r) return null;
  pauseRunning();
  const total = r.prior + r.accum;
  const start = floor30(r.sessionStart);
  const end = start + ceilHalf(total);
  const b = state.blocks[r.bid], it = state.items[b.itemId];
  const res = { name: blockName(r.bid), total, start, end };
  if (b.subId) {
    const s = it.subtasks.find(x => x.id === b.subId); if (s) s.done = true;
  } else if (it.type === 'task') {
    if (!it.recurring) delete state.items[it.id];
  } else if (it.type === 'list') {
    if (!it.recurring) delete state.items[it.id];
    else if (it.recSubtasks) it.subtasks.forEach(s => { s.done = false; });
    else it.subtasks = [];
  }
  delete state.blocks[r.bid];
  state.running = null;
  save();
  return res;
}
