/* Paradigm: Google Calendar + Drive (free tier, browser token flow). */
'use strict';

const SCOPES = 'https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/drive.appdata';
const CAL = 'https://www.googleapis.com/calendar/v3';
const BACKUP_NAME = 'paradigm-backup.json';
const TZ = Intl.DateTimeFormat().resolvedOptions().timeZone;

let tokenClient = null, tokenClientFor = '', tokenWaiters = [], tokenPending = false, backupDirty = false, backupTimer = null;

const gisReady = () => !!(window.google && google.accounts && google.accounts.oauth2);
function tokenValid() { return !!state.auth.token && Date.now() < state.auth.exp - MIN; }

function ensureTokenClient() {
  const id = (state.settings.clientId || '').trim();
  if (!id || !gisReady()) return null;
  if (tokenClient && tokenClientFor === id) return tokenClient;
  tokenClientFor = id;
  tokenClient = google.accounts.oauth2.initTokenClient({
    client_id: id, scope: SCOPES,
    callback: resp => {
      if (resp && resp.access_token) {
        state.auth.token = resp.access_token;
        state.auth.exp = Date.now() + (Number(resp.expires_in) || 3600) * 1000;
        state.settings.connected = true;
        save({ noBackup: true });
        settleTokens(resp.access_token);
        if (backupDirty) driveBackup();
      } else settleTokens(null);
    },
    error_callback: () => settleTokens(null)
  });
  return tokenClient;
}
function settleTokens(tok) { tokenPending = false; const w = tokenWaiters; tokenWaiters = []; w.forEach(f => f(tok)); if (typeof renderSettings === 'function') renderSettings(); }

/* Call FIRST inside a tap/swipe handler (before any await) so the sign-in popup is allowed. */
function getToken(interactive, forceConsent) {
  if (tokenValid() && !forceConsent) return Promise.resolve(state.auth.token);
  if (!interactive) return Promise.resolve(null);
  const tc = ensureTokenClient();
  if (!tc) return Promise.resolve(null);
  return new Promise(res => {
    tokenWaiters.push(res);
    if (tokenPending) return;
    tokenPending = true;
    try { tc.requestAccessToken({ prompt: forceConsent || !state.settings.connected ? 'consent' : '' }); }
    catch (e) { settleTokens(null); }
  });
}

async function gfetch(tok, method, url, body, headers) {
  const h = Object.assign({ Authorization: 'Bearer ' + tok }, headers || {});
  let payload = body;
  if (body !== undefined && body !== null && typeof body !== 'string') { payload = JSON.stringify(body); h['Content-Type'] = 'application/json'; }
  const r = await fetch(url, { method, headers: h, body: payload });
  if (r.status === 401) { state.auth.token = ''; state.auth.exp = 0; throw Object.assign(new Error('auth'), { status: 401 }); }
  if (!r.ok) throw Object.assign(new Error('http ' + r.status), { status: r.status });
  if (r.status === 204) return null;
  const ct = r.headers.get('content-type') || '';
  return ct.includes('json') ? r.json() : r.text();
}

/* ---------- Calendar ---------- */
async function paradigmCalId(tok) {
  if (state.settings.paradigmCalId) return state.settings.paradigmCalId;
  const list = await gfetch(tok, 'GET', `${CAL}/users/me/calendarList?maxResults=250`);
  let cal = (list.items || []).find(c => c.summary === 'Paradigm');
  if (!cal) cal = await gfetch(tok, 'POST', `${CAL}/calendars`, { summary: 'Paradigm', timeZone: TZ });
  state.settings.paradigmCalId = cal.id; save({ noBackup: true });
  return cal.id;
}
function eventTimes(ev) {
  if (ev.allDay) return { start: { date: ev.date }, end: { date: addDays(ev.date, 1) } };
  const base = parseDate(ev.date).getTime();
  return {
    start: { dateTime: new Date(base + ev.startMin * MIN).toISOString(), timeZone: TZ },
    end: { dateTime: new Date(base + ev.endMin * MIN).toISOString(), timeZone: TZ }
  };
}
async function calInsertEvent(tok, name, ev) {
  const r = await gfetch(tok, 'POST', `${CAL}/calendars/primary/events`, Object.assign({ summary: name }, eventTimes(ev)));
  return r.id;
}
async function calUpdateEvent(tok, id, name, ev) {
  await gfetch(tok, 'PATCH', `${CAL}/calendars/primary/events/${encodeURIComponent(id)}`, Object.assign({ summary: name }, eventTimes(ev)));
}
async function calDeleteEvent(tok, id) {
  try { await gfetch(tok, 'DELETE', `${CAL}/calendars/primary/events/${encodeURIComponent(id)}`); }
  catch (e) { if (e.status !== 404 && e.status !== 410) throw e; }
}
async function calLogCompletion(tok, res) {
  const body = {
    summary: res.name,
    description: `Worked ${fmtDur(res.total)} in Paradigm`,
    start: { dateTime: new Date(res.start).toISOString(), timeZone: TZ },
    end: { dateTime: new Date(res.end).toISOString(), timeZone: TZ }
  };
  let id = await paradigmCalId(tok);
  try { await gfetch(tok, 'POST', `${CAL}/calendars/${encodeURIComponent(id)}/events`, body); }
  catch (e) {
    if (e.status !== 404) throw e;
    state.settings.paradigmCalId = '';
    id = await paradigmCalId(tok);
    await gfetch(tok, 'POST', `${CAL}/calendars/${encodeURIComponent(id)}/events`, body);
  }
}
/* Existing events for a day, for the dimmed background in day views. Never prompts. */
async function calDayEvents(date) {
  const tok = await getToken(false);
  if (!tok) return null;
  const t0 = parseDate(date).getTime();
  const q = `timeMin=${encodeURIComponent(new Date(t0).toISOString())}&timeMax=${encodeURIComponent(new Date(t0 + DAY).toISOString())}&singleEvents=true&orderBy=startTime&maxResults=100`;
  const cals = ['primary'];
  if (state.settings.paradigmCalId) cals.push(state.settings.paradigmCalId);
  const out = [];
  for (const c of cals) {
    try {
      const r = await gfetch(tok, 'GET', `${CAL}/calendars/${encodeURIComponent(c)}/events?${q}`);
      (r.items || []).forEach(e => out.push(e));
    } catch (e) { /* show what we can */ }
  }
  return out;
}

/* One-tap fallback when Google access has lapsed. */
function calLink(name, ev, details) {
  const f = ms => new Date(ms).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  let dates;
  if (ev.allDay) dates = `${ev.date.replace(/-/g, '')}/${addDays(ev.date, 1).replace(/-/g, '')}`;
  else if (ev.startMs) dates = `${f(ev.startMs)}/${f(ev.endMs)}`;
  else { const b = parseDate(ev.date).getTime(); dates = `${f(b + ev.startMin * MIN)}/${f(b + ev.endMin * MIN)}`; }
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(name)}&dates=${dates}${details ? '&details=' + encodeURIComponent(details) : ''}`;
}

/* ---------- Drive backup (hidden app folder) ---------- */
function exportable() {
  const s = clone(state);
  delete s.auth;
  s.settings = { clientId: state.settings.clientId };
  s.exportedAt = Date.now();
  return s;
}
function scheduleBackup() {
  if (!state.settings.connected) return;
  backupDirty = true;
  clearTimeout(backupTimer);
  backupTimer = setTimeout(driveBackup, 4000);
}
async function driveFileId(tok) {
  if (state.settings.driveFileId) return state.settings.driveFileId;
  const q = encodeURIComponent(`name='${BACKUP_NAME}'`);
  const r = await gfetch(tok, 'GET', `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,modifiedTime)`);
  const id = r.files && r.files[0] ? r.files[0].id : '';
  state.settings.driveFileId = id;
  return id;
}
async function driveBackup(interactiveTokPromise) {
  const tok = interactiveTokPromise ? await interactiveTokPromise : await getToken(false);
  if (!tok) { backupDirty = true; return false; }
  try {
    const data = JSON.stringify(exportable());
    let id = await driveFileId(tok);
    if (id) {
      try { await gfetch(tok, 'PATCH', `https://www.googleapis.com/upload/drive/v3/files/${id}?uploadType=media`, data, { 'Content-Type': 'application/json' }); }
      catch (e) { if (e.status === 404) id = ''; else throw e; }
    }
    if (!id) {
      const b = 'paradigm' + uid();
      const meta = JSON.stringify({ name: BACKUP_NAME, parents: ['appDataFolder'] });
      const body = `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${b}\r\nContent-Type: application/json\r\n\r\n${data}\r\n--${b}--`;
      const r = await gfetch(tok, 'POST', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id', body, { 'Content-Type': `multipart/related; boundary=${b}` });
      state.settings.driveFileId = r.id;
    }
    backupDirty = false;
    state.settings.lastBackup = Date.now();
    save({ noBackup: true });
    if (typeof renderSettings === 'function') renderSettings();
    return true;
  } catch (e) { console.warn('backup failed', e); backupDirty = true; return false; }
}
async function driveRestore(tokPromise) {
  const tok = await tokPromise;
  if (!tok) throw new Error('Not connected to Google');
  state.settings.driveFileId = '';
  const id = await driveFileId(tok);
  if (!id) throw new Error('No backup found in Drive');
  const r = await fetch(`https://www.googleapis.com/drive/v3/files/${id}?alt=media`, { headers: { Authorization: 'Bearer ' + tok } });
  if (!r.ok) throw new Error('Download failed');
  return r.json();
}
